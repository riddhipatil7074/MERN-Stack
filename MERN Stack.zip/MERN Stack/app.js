const express = require('express');
const mongoose = require('mongoose');
require('dotenv').config();

const initRoutes = require('./routes/initRoutes');
const transactionsRoutes = require('./routes/transactionsRoutes');
const statisticsRoutes = require('./routes/statisticsRoutes');
const chartsRoutes = require('./routes/chartsRoutes');
const combinedRoutes = require('./routes/combinedRoutes');

const app = express();
app.use(express.json());

// API Routes
app.use('/api', initRoutes);
app.use('/api', transactionsRoutes);
app.use('/api', statisticsRoutes);
app.use('/api', chartsRoutes);
app.use('/api', combinedRoutes);

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
