const mongoose = require('mongoose');

// Define the transaction schema
const transactionSchema = new mongoose.Schema({
  title: String,
  description: String,
  price: Number,
  dateOfSale: Date,
  category: String,
  isSold: Boolean
});

module.exports = mongoose.model('Transaction', transactionSchema);
