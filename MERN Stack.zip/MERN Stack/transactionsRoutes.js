const express = require('express');
const { listTransactions } = require('../controllers/transactionsController');
const router = express.Router();

router.get('/transactions', listTransactions);

module.exports = router;
