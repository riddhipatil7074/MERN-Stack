document.addEventListener('DOMContentLoaded', function () {
    const monthSelect = document.getElementById('monthSelect');
    const searchBox = document.getElementById('searchBox');
    const transactionsTableBody = document.querySelector('#transactionsTable tbody');
    const prevPageButton = document.getElementById('prevPage');
    const nextPageButton = document.getElementById('nextPage');
    const totalSaleEl = document.getElementById('totalSale');
    const soldItemsEl = document.getElementById('soldItems');
    const notSoldItemsEl = document.getElementById('notSoldItems');
    const ctx = document.getElementById('transactionsChart').getContext('2d');
    
    let currentPage = 1;
    let currentMonth = monthSelect.value;
    
    // Function to fetch transactions data
    async function fetchTransactions(month, page = 1, searchQuery = '') {
      const apiUrl = `/api/transactions?month=${month}&page=${page}&search=${searchQuery}`;
      const response = await fetch(apiUrl);
      const data = await response.json();
      return data;
    }
    
    // Function to render transactions in table
    function renderTransactions(transactions) {
      transactionsTableBody.innerHTML = '';
      transactions.forEach(tx => {
        const row = `
          <tr>
            <td>${tx.title}</td>
            <td>${tx.description}</td>
            <td>${tx.price}</td>
            <td>${tx.date}</td>
          </tr>
        `;
        transactionsTableBody.innerHTML += row;
      });
    }
  
    // Function to fetch and display statistics
    async function fetchAndDisplayStatistics(month) {
      const apiUrl = `/api/transactions/stats?month=${month}`;
      const response = await fetch(apiUrl);
      const { totalSale, soldItems, notSoldItems } = await response.json();
      
      totalSaleEl.textContent = totalSale;
      soldItemsEl.textContent = soldItems;
      notSoldItemsEl.textContent = notSoldItems;
    }
    
    // Function to render the bar chart
    async function renderBarChart(month) {
      const apiUrl = `/api/transactions/chart?month=${month}`;
      const response = await fetch(apiUrl);
      const data = await response.json();
      
      const chartData = {
        labels: data.priceRanges,
        datasets: [{
          label: 'Number of Items',
          data: data.itemCounts,
          backgroundColor: 'rgba(75, 192, 192, 0.6)',
          borderColor: 'rgba(75, 192, 192, 1)',
          borderWidth: 1
        }]
      };
      
      new Chart(ctx, {
        type: 'bar',
        data: chartData,
        options: {
          scales: {
            y: {
              beginAtZero: true
            }
          }
        }
      });
    }
    
    // Initial load
    async function loadPage() {
      const transactions = await fetchTransactions(currentMonth, currentPage);
      renderTransactions(transactions);
      await fetchAndDisplayStatistics(currentMonth);
      await renderBarChart(currentMonth);
    }
    
    // Handle month change
    monthSelect.addEventListener('change', async (event) => {
      currentMonth = event.target.value;
      currentPage = 1;
      loadPage();
    });
    
    // Handle search
    searchBox.addEventListener('input', async (event) => {
      const searchQuery = event.target.value;
      const transactions = await fetchTransactions(currentMonth, currentPage, searchQuery);
      renderTransactions(transactions);
    });
    
    // Handle pagination
    nextPageButton.addEventListener('click', async () => {
      currentPage += 1;
      loadPage();
    });
    
    prevPageButton.addEventListener('click', async () => {
      if (currentPage > 1) {
        currentPage -= 1;
        loadPage();
      }
    });
    
    // Initial load on page load
    loadPage();
  });
  