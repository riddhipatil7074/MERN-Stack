const express = require('express');
const { initializeDB } = require('../controllers/initController');
const router = express.Router();

router.get('/initialize-db', initializeDB);

module.exports = router;
