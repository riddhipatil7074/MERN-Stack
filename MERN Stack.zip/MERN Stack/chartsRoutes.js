const express = require('express');
const { getBarChartData } = require('../controllers/chartsController');
const router = express.Router();

router.get('/bar-chart', getBarChartData);

module.exports = router;
router.get('/pie-chart', getPieChartData);

module.exports = router;
