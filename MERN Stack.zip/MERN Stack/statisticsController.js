const Transaction = require('../models/transactionModel');

const getStatistics = async (req, res) => {
  const { month } = req.query;

  try {
    const soldItems = await Transaction.countDocuments({
      $expr: { $eq: [{ $month: "$dateOfSale" }, parseInt(month)] },
      isSold: true
    });

    const notSoldItems = await Transaction.countDocuments({
      $expr: { $eq: [{ $month: "$dateOfSale" }, parseInt(month)] },
      isSold: false
    });

    const totalSale = await Transaction.aggregate([
      {
        $match: {
          $expr: { $eq: [{ $month: "$dateOfSale" }, parseInt(month)] },
          isSold: true
        }
      },
      {
        $group: { _id: null, totalAmount: { $sum: "$price" } }
      }
    ]);

    res.status(200).json({
      totalSaleAmount: totalSale[0] ? totalSale[0].totalAmount : 0,
      totalSoldItems: soldItems,
      totalNotSoldItems: notSoldItems
    });
  } catch (error) {
    res.status(500).json({ error: 'Error fetching statistics' });
  }
};

module.exports = { getStatistics };
