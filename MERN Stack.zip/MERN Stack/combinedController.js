const { getStatistics } = require('./statisticsController');
const { getBarChartData, getPieChartData } = require('./chartsController');

const getCombinedData = async (req, res) => {
  const { month } = req.query;

  try {
    const statistics = await getStatistics({ query: { month } }, res);
    const barChartData = await getBarChartData({ query: { month } }, res);
    const pieChartData = await getPieChartData({ query: { month } }, res);

    res.status(200).json({
      statistics,
      barChartData,
      pieChartData
    });
  } catch (error) {
    res.status(500).json({ error: 'Error fetching combined data' });
  }
};

module.exports = { getCombinedData };
