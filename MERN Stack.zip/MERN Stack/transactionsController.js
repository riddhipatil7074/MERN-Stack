const Transaction = require('../models/transactionModel');

const listTransactions = async (req, res) => {
  const { page = 1, perPage = 10, search = '', month } = req.query;

  try {
    const searchQuery = {
      $and: [
        { $expr: { $eq: [{ $month: "$dateOfSale" }, parseInt(month)] } },
        {
          $or: [
            { title: { $regex: search, $options: 'i' } },
            { description: { $regex: search, $options: 'i' } },
            { price: { $regex: search, $options: 'i' } }
          ]
        }
      ]
    };

    const transactions = await Transaction.find(searchQuery)
      .skip((page - 1) * perPage)
      .limit(parseInt(perPage));

    const totalCount = await Transaction.countDocuments(searchQuery);

    res.status(200).json({
      page,
      perPage,
      totalPages: Math.ceil(totalCount / perPage),
      totalTransactions: totalCount,
      transactions
    });
  } catch (error) {
    res.status(500).json({ error: 'Error fetching transactions' });
  }
};

module.exports = { listTransactions };
