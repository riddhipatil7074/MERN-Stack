const axios = require('axios');
const Transaction = require('../models/transactionModel');

// Initialize database with seed data from third-party API
const initializeDB = async (req, res) => {
  try {
    const response = await axios.get('https://third-party-api-url.com/data'); // Replace with actual API
    const data = response.data;

    // Seed the database with the fetched data
    await Transaction.insertMany(data);
    res.status(200).json({ message: 'Database initialized successfully!' });
  } catch (error) {
    res.status(500).json({ error: 'Error initializing the database' });
  }
};

module.exports = { initializeDB };
